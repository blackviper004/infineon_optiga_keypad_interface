var group__group__bsp__pins__wco =
[
    [ "CYBSP_WCO_IN", "group__group__bsp__pins__wco.html#gac07a2f3b38920ceba85a621a2196d18f", null ],
    [ "CYBSP_WCO_OUT", "group__group__bsp__pins__wco.html#ga6f2a01a38771377b6fe57eb673f21380", null ]
];