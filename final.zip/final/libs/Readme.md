#Matrix Keypad Library

This is a library for interfacing with matrix keypads. It provides functions for initializing the keypad, scanning for button presses, and returning the pressed button.


## Installation

To use this library, simply download the `matrix_keypad.c` and `matrix_keypad.h` files and add them to your PSOC project directory.

## Usage

To use the library, include the `matrix_keypad.h` header file in your main sketch:

```c
#include <matrix_keypad.h>
```

## Data Types

### MatrixKeypad_t

Structure that holds the physical parameters of the keypad, the pin mapping, the key mapping and the state variables.

#####Fields

* **`uint8_t row_n`** Number of rows. Must be greater than zero.
* **`uint8_t column_n`** Number of columns. Must be greater than zero.
* **`uint8_t *row_pins`** Pin mapping for the rows. These pins are set as output. Is a unidimentional matrix with length = _"rown"_.
* **`uint8_t *column_pins`** Pin mapping for the columns. These pins are set as inputs. Is a unidimentional matrix with length = _"coln"_.
* **`char *keymap`_** Key mapping for the keypad. Its a bidimentional matrix with _"rown"_ rows and _"coln"_ columns. When a keypress is detect at row R and column C, the returned key is the one at _keyMap R][C] the key mapping is directly related to the pin mappings. Dont use '\0' as a mapped key.
* **`char lastkey`** Holds the last key detected. Used to avoid the same keypress to be read multiple times.
* **`char buffer`** Holds the last key accepted. Is cleared after the keypress is requested. Its overwritten if a new key is pressed before the old one is requested.

## Functions

### matrix_keypad_init

A matrix keypad will have some pins or wires that you have to connect to digital inputs of the development board.  
You will need to sort out which pins are connected to the rows, which are connected to the columns and their ordering.  
Then define a matrix and initialize it with the ordered row pin number. Define another matrix for the columns.  
To create the key mapping, define a bidimensional array and initialize with the character to be returned when the key on it's place is pressed.  
Note that the key mapping ordering is directly related to the pin mapping ordering.

```c
void matrix_keypad_init(char *keymap, cyhal_gpio_t *row_pins, cyhal_gpio_t *column_pins, uint8_t row_n, uint8_t column_n)
```

#####Parameters

* **`keymap`** Key mapping for the keypad. Its a bidimentional matrix with _"row_n"_ rows and _"col_n"_ columns. You can define a variable as _`char keymap[row_n][col_n]`_ and cast it as _`(char*)keymap`_.
* **`row_pins`** Pin mapping for the rows. Is a unidimentional matrix with length "_row_n"_.
* **`column_pins`** Pin mapping for the columns. Is a unidimentional matrix with length _"col_n"_.
* **`row_n`** Number of rows. Must be greater than zero.
* **`column_n`** Number of columns. Must be greater than zero.

As an example, consider a 4x4 keypad:

```c
uint8_t row_n = 4; //4 rows
uint8_t column_n = 4; //4 columns
uint8_t row_pins[row_n] = {10, 9, 8, 7};  //first row is connect to pin 10, second to 9...
uint8_t column_pins[column_n] = {6, 5, 4, 3}//first column is connect to pin 6, second to 5...
char keymap[row_n][column_n] =
  {{'1','2','3','A'}, //key of the first row first column is '1', frist row second column column is '2'
   {'4','5','6','B'}, //key of the second row first column is '4', second row second column column is '5'
   {'7','8','9','C'},
   {'*','0','#','D'}};
matrix_keypad_t *keypad = matrix_keypad_init((char*)keymap, row_pins, column_pins, row_n, column_n); //keypad is the variable that you will need to pass to the other functions

```

### matrix_keypad_scan

Scans a matrix keypad to detect key presses..
This function must be called inside the loop function to scan the keypad periodically 
You can put a lower limit on the scan interval to at least 5ms using the `cyhal_system_delay_ms(5)`

```
void matrix_keypad_scan()
```

### matrix_keypad_hasKey

Checks if a keypress was detected.

```
uint8_t matrix_keypad_hasKey ();
```

##### Returns

1 if a key was pressed or 0 if none was pressed.

### matrix_keypad_getKey

This function returns the last key press that was stored in the keypad buffer  
You must use the `MatrixKeypad_scan` function to scan the keypad periodically.

```
char matrix_keypad_getKey ();
```

#####Returns

The pressed key character from the key mapping or '\0' (null character) if none key was pressed.

### matrix_keypad_waitForKey

Waits until a key is pressed and returns it.
If no key is pressed, the function will keep scanning the keypad until a key is detected.
This function is **BLOCKING**. The program will freeze until a key press is detected.

```
char matrix_keypad_waitForKey ();
```

##### Returns

The pressed key character from the key mapping.

### matrix_keypad_flush

Flushes the unread keys buffer of a matrix keypad

```
void matrix_keypad_flush ();
```
### matrix_keypad_add_event_listener

Adds an event listener function as the callback for all keypad column interrupts (GPIO_KEYPAD_COL0-3), which will be triggered on rising edge interrupts.

```
void matrix_keypad_add_event_listener(void (*listener)(void*, cyhal_gpio_event_t));
```

### Limitations

- Don't handle multiples keypress simultaneously; 
- Saves only the last key pressed.
